import { Hook } from '@oclif/core';
declare const brewHook: Hook<'update'>;
export default brewHook;
