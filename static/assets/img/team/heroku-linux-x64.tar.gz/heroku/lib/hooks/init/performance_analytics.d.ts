import { Hook } from '@oclif/core';
declare const performance_analytics: Hook<'init'>;
export default performance_analytics;
