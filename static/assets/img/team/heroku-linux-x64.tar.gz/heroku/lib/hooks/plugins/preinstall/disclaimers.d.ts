import { Hook } from '@oclif/core';
declare const hook: Hook<'plugins:preinstall'>;
export default hook;
