export default function (): string;
