export default function (date: string): string;
