export declare function ago(since: Date): string;
export declare function remaining(from: number, to: number): string;
