import { Command } from '@heroku-cli/command';
export declare function createSourceBlob(ref: any, command: Command): Promise<any>;
