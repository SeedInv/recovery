export default function parseKeyValue(input: string): {
    key: string;
    value: string;
};
