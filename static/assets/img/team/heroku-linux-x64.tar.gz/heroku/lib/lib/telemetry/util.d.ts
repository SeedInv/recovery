import { TelemetryDrain } from '../types/telemetry';
export declare function validateAndFormatSignals(signalInput: string | undefined): string[];
export declare function displayTelemetryDrain(telemetryDrain: TelemetryDrain): void;
