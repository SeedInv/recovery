from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile
from django_countries.fields import CountryField 


class RegistrationForm(UserCreationForm):
    # These fields belong to the User model, so leave them out of UserProfile
    first_name = forms.CharField(max_length=100, required=False)
    last_name = forms.CharField(max_length=100, required=False)
    username = forms.CharField(max_length=150, required=True)

    # Other fields
    phone_number = forms.CharField(required=False)
    profile_image = forms.ImageField(required=False)
    wallet_address = forms.CharField(max_length=255, required=False, widget=forms.TextInput(attrs={'placeholder': 'Enter your wallet address'}))
    email = forms.EmailField(required=False, widget=forms.EmailInput(attrs={'placeholder': 'Enter your email address'}))
    country = CountryField(blank_label='(Select Country)').formfield(required=False)  # Use CountryField here
    address = forms.CharField(widget=forms.Textarea(attrs={'placeholder': 'Enter your address'}), required=False)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        
        if commit:
            user.save()

        # Create the user profile with additional fields
        user_profile = UserProfile.objects.create(user=user)
        user_profile.phone_number = self.cleaned_data['phone_number']
        if 'profile_image' in self.cleaned_data:
            user_profile.profile_image = self.cleaned_data['profile_image']
        if 'wallet_address' in self.cleaned_data:
            user_profile.wallet_address = self.cleaned_data['wallet_address']
        if 'email' in self.cleaned_data:
            user_profile.email = self.cleaned_data['email']
        if 'country' in self.cleaned_data:
            user_profile.country = self.cleaned_data['country']
        if 'address' in self.cleaned_data:
            user_profile.address = self.cleaned_data['address']
        
        user_profile.save()
        return user
    






class LoginForm(forms.Form):
    username = forms.CharField(max_length=150, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}))

