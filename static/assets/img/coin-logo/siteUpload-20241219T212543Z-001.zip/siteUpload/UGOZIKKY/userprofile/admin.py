from django.contrib import admin
from .models import UserProfile

class UserProfileAdmin(admin.ModelAdmin):
    # Add 'phone_number' to the list_display
    list_display = ('get_full_name', 'email', 'phone_number', 'country', 'wallet_address')

    # Custom method to display full name (combining first and last name)
    def get_full_name(self, obj):
        return f"{obj.user.first_name} {obj.user.last_name}"
    get_full_name.admin_order_field = 'user__first_name'  # Enables sorting by full name
    get_full_name.short_description = 'Full Name'  # Column header text

    # Add search functionality for the phone number
    search_fields = ('user__username', 'user__first_name', 'user__last_name', 'email', 'wallet_address', 'phone_number')

    # Filter by country (optional)
    list_filter = ('country',)

    # Editable fields in the list view (optional)
    list_editable = ('email', 'phone_number', 'country', 'wallet_address')

    # Define the fields for the detailed profile view in the admin
    fieldsets = (
        (None, {
            'fields': ('user', 'phone_number', 'profile_image', 'wallet_address', 'email', 'country', 'address')
        }),
    )

# Register the UserProfile model with the custom admin class
admin.site.register(UserProfile, UserProfileAdmin)
