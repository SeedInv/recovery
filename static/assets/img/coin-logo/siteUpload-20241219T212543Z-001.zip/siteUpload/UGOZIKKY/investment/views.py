# from django.shortcuts import render, redirect
# from django.contrib.auth.decorators import login_required
# from .models import Investment, Transaction, WithdrawalRequest
# from userprofile.models import UserProfile

# @login_required
# def account_statement(request):
#     user_transactions = Transaction.objects.filter(user=request.user).order_by('-created_at')
#     return render(request, 'investment/account_statement.html', {'transactions': user_transactions})

# @login_required
# def deposit(request):
#     if request.method == 'POST':
#         amount = float(request.POST.get('amount'))
#         user_profile = request.user.userprofile
#         user_profile.balance += amount * 5  # Apply the multiplier
#         user_profile.save()

#         Transaction.objects.create(
#             user=request.user,
#             amount=amount,
#             transaction_type='deposit',
#             status='approved',
#             description="Deposit"
#         )

#         return redirect('account_statement')
#     return render(request, 'investment/deposit.html')

# @login_required
# def create_investment(request):
#     if request.method == 'POST':
#         amount = float(request.POST.get('amount'))
#         user_profile = request.user.userprofile

#         if user_profile.balance >= amount:
#             investment = Investment.objects.create(user_profile=user_profile, deposit_amount=amount)
#             user_profile.balance -= amount
#             user_profile.save()
#             investment.activate_investment()
#             return redirect('account_statement')
#     return render(request, 'investment/create_investment.html')

# @login_required
# def withdrawal_request(request):
#     if request.method == 'POST':
#         amount = float(request.POST.get('amount'))
#         user_profile = request.user.userprofile

#         if user_profile.balance >= amount:
#             WithdrawalRequest.objects.create(user_profile=user_profile, amount=amount)
#             return redirect('account_statement')
#     return render(request, 'investment/withdrawal_request.html')



from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Investment, Transaction, WithdrawalRequest
from userprofile.models import UserProfile  # Make sure UserProfile is correctly imported
from decimal import Decimal
from django.contrib import messages
from decimal import Decimal, InvalidOperation

@login_required
def account_statement(request):
    # Fetch all transactions for the logged-in user (both deposits and withdrawals)
    user_transactions = Transaction.objects.filter(user=request.user).order_by('-created_at')
    user_profile = request.user.userprofile  # Get the current user profile

    return render(request, 'investment/account_statement.html', {
        'transactions': user_transactions,  # Pass transactions to template
        'balance': user_profile.balance,    # Pass the user's balance to template
    })




@login_required
def deposit(request):
    if request.method == 'POST':
        try:
            # Retrieve the deposit amount and convert to Decimal
            amount = Decimal(request.POST.get('amount'))
        except (TypeError, ValueError):
            # Handle invalid input gracefully
            return redirect('account_statement')  # Redirect or show an error message

        # Access the UserProfile through the related `userprofile` field
        user_profile = request.user.userprofile

        # Update the balance with the multiplier (assumed business logic)
        user_profile.balance += amount * 5  # Assuming the amount is multiplied by 5 as part of your logic
        user_profile.save()  # Save the updated balance

        # Create a new transaction entry for the deposit
        Transaction.objects.create(
            user=request.user,
            amount=amount,
            transaction_type='deposit',
            status='approved',  # Mark as approved for now
            description="Deposit"
        )

        # Redirect the user back to the account statement with the updated balance
        return redirect('account_statement')

    # If it's a GET request, render the deposit page
    return render(request, 'investment/deposit.html')


@login_required
def create_investment(request):
    if request.method == 'POST':
        try:
            # Retrieve the investment amount
            amount = float(request.POST.get('amount'))
        except (TypeError, ValueError):
            return redirect('account_statement')  # Handle invalid amount gracefully

        user_profile = request.user.userprofile  # Get the user profile

        if user_profile.balance >= amount:
            # If balance is sufficient, create the investment
            investment = Investment.objects.create(user_profile=user_profile, deposit_amount=amount)
            user_profile.balance -= amount  # Deduct the investment amount from balance
            user_profile.save()  # Save the updated balance

            # Activate the investment (assuming this is a method defined in your model)
            investment.activate_investment()

            return redirect('account_statement')
        else:
            # Handle insufficient balance (perhaps show a message to the user)
            pass

    return render(request, 'investment/create_investment.html')


@login_required
def withdrawal_request(request):
    if request.method == 'POST':
        try:
            # Retrieve and validate the withdrawal amount
            amount = Decimal(request.POST.get('amount'))  # Use Decimal to avoid float issues
        except (TypeError, ValueError, InvalidOperation):
            # Handle invalid amount gracefully
            messages.error(request, "Invalid amount entered. Please enter a valid number.")
            return redirect('account_statement')  # Redirect back to the account statement page

        user_profile = request.user.userprofile  # Get the user profile

        # Check if the user has sufficient balance
        if user_profile.balance >= amount:
            # If balance is sufficient, create the withdrawal transaction record
            Transaction.objects.create(
                user=request.user,
                amount=amount,
                transaction_type='withdrawal',
                status='pending',  # Set status to 'pending' for admin approval
                description="Withdrawal Request"
            )

            # Subtract the amount from the user's balance
            user_profile.balance -= amount
            user_profile.save()  # Save the updated balance

            # Show success message to the user
            messages.success(request, f"Your withdrawal request for ${amount} has been submitted and is pending approval.")

            # Redirect to account statement after creating withdrawal
            return redirect('account_statement')
        else:
            # Handle insufficient balance for withdrawal
            messages.error(request, "You do not have enough balance to make this withdrawal.")
            return redirect('account_statement')

    # Render the withdrawal request form page
    return render(request, 'investment/withdrawal_request.html')