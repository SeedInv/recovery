from django.db import models
from django.contrib.auth.models import User
from userprofile.models import UserProfile
from decimal import Decimal
import time
from django.core.mail import send_mail

class Transaction(models.Model):
    """
    Tracks user transactions such as deposits, withdrawals, and profits.
    """
    TRANSACTION_TYPE_CHOICES = [
        ('deposit', 'Deposit'),
        ('withdrawal', 'Withdrawal'),
        ('profit', 'Profit'),
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(
        max_length=20,
        choices=TRANSACTION_TYPE_CHOICES
    )
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.transaction_type.capitalize()} of ${self.amount} by {self.user.username}"

    def approve(self):
        """
        Admin approves the transaction.
        """
        if self.status == 'pending':
            self.status = 'approved'
            self.save()
            # Send email notification to the user
            send_mail(
                subject="Transaction Approved",
                message=f"Your {self.transaction_type} of ${self.amount} has been approved.",
                from_email="no-reply@yourdomain.com",
                recipient_list=[self.user.email],
            )


class Investment(models.Model):
    """
    Tracks user investments, including deposit amount, ROI, and referral bonus.
    """
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    deposit_amount = models.DecimalField(max_digits=15, decimal_places=2)
    roi_accumulated = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))
    deposit_time = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)  # Timestamp for the last update
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Investment of ${self.deposit_amount} by {self.user_profile.user.username}"

    def calculate_roi(self):
        """
        Calculates the ROI based on time elapsed since the deposit was made.
        The ROI is updated every second.
        """
        time_elapsed = (time.time() - self.deposit_time.timestamp())  # Elapsed time in seconds
        roi = self.deposit_amount * Decimal('0.01')  # 1% ROI per second
        return roi * time_elapsed

    def activate_investment(self):
        """
        Activates the investment and multiplies the deposit by 5.
        """
        self.deposit_amount *= 5  # Multiply deposit by 5
        self.save()

    def withdraw(self, amount):
        """
        Withdraw an amount from the investment.
        If the withdrawal exceeds the available balance, it returns False.
        """
        if self.roi_accumulated >= amount:
            self.roi_accumulated -= amount
            self.save()
            return True
        return False

    def update_roi(self):
        """
        Updates the ROI for the investment by calculating the new accumulated ROI.
        """
        time_elapsed = (time.time() - self.last_updated.timestamp())  # Time difference in seconds
        new_roi = self.calculate_roi()
        self.roi_accumulated = new_roi
        self.last_updated = models.DateTimeField(auto_now=True)  # Update the last update timestamp
        self.save()


# class WithdrawalRequest(models.Model):
#     """
#     Tracks withdrawal requests by users.
#     """
#     user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
#     amount = models.DecimalField(max_digits=10, decimal_places=2)
#     created_at = models.DateTimeField(auto_now_add=True)
#     approved = models.BooleanField(default=False)

#     def approve(self):
#         """
#         Approve the withdrawal request, deduct from balance, and notify user.
#         """
#         if self.user_profile.balance >= self.amount:
#             self.user_profile.balance -= self.amount
#             self.user_profile.save()
#             self.approved = True
#             self.save()

#             # Create an approved transaction
#             Transaction.objects.create(
#                 user=self.user_profile.user,
#                 amount=self.amount,
#                 transaction_type='withdrawal',
#                 status='approved',
#                 description="Approved withdrawal"
#             )

#             # Send approval email
#             send_mail(
#                 subject="Withdrawal Approved",
#                 message=f"Your withdrawal of ${self.amount} has been approved.",
#                 from_email="no-reply@yourdomain.com",
#                 recipient_list=[self.user_profile.user.email],
#             )
#         else:
#             raise ValueError("Insufficient balance to approve this withdrawal")

#     def __str__(self):
#         return f"Withdrawal request by {self.user_profile.user.username} for ${self.amount}"


class WithdrawalRequest(models.Model):
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    approved = models.BooleanField(default=False)

    def approve(self):
        """
        Approve the withdrawal request, deduct from balance, and notify user.
        """
        if self.user_profile.balance >= self.amount:
            # Deduct from user balance
            self.user_profile.balance -= self.amount
            self.user_profile.save()

            # Update withdrawal request status to approved
            self.approved = True
            self.save()

            # Create an approved transaction record
            Transaction.objects.create(
                user=self.user_profile.user,
                amount=self.amount,
                transaction_type='withdrawal',
                status='approved',
                description="Approved withdrawal"
            )

            # Send approval email
            send_mail(
                subject="Withdrawal Approved",
                message=f"Your withdrawal of ${self.amount} has been approved.",
                from_email="no-reply@yourdomain.com",
                recipient_list=[self.user_profile.user.email],
            )
        else:
            raise ValueError("Insufficient balance to approve this withdrawal")

    def __str__(self):
        return f"Withdrawal request by {self.user_profile.user.username} for ${self.amount}"
