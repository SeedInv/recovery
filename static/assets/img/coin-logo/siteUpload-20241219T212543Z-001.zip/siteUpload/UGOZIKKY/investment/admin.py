# from django.contrib import admin
# from .models import Transaction, Investment, WithdrawalRequest

# # Customize the Transaction model in the admin
# class TransactionAdmin(admin.ModelAdmin):
#     list_display = ('user', 'amount', 'transaction_type', 'status', 'created_at', 'description')
#     list_filter = ('transaction_type', 'status')  # Add filters to the sidebar
#     search_fields = ('user__username', 'transaction_type', 'description')  # Add search functionality
#     ordering = ('-created_at',)  # Order by latest created_at by default

# # Customize the Investment model in the admin
# class InvestmentAdmin(admin.ModelAdmin):
#     list_display = ('get_user', 'deposit_amount', 'roi_accumulated', 'deposit_time', 'last_updated', 'is_active')
#     list_filter = ('is_active',)
#     search_fields = ('user_profile__user__username', 'deposit_amount')
#     ordering = ('-deposit_time',)

#     def get_user(self, obj):
#         """
#         Custom method to get the username from the related UserProfile
#         """
#         return obj.user_profile.user.username
#     get_user.short_description = 'User'  # Custom column header in the admin list view

# # Customize the WithdrawalRequest model in the admin
# class WithdrawalRequestAdmin(admin.ModelAdmin):
#     list_display = ('get_user', 'amount', 'created_at', 'approved')
#     list_filter = ('approved',)  # Filter by approval status
#     search_fields = ('user_profile__user__username', 'amount')
#     ordering = ('-created_at',)

#     # Custom method to get the username
#     def get_user(self, obj):
#         """
#         Custom method to get the username from the related UserProfile
#         """
#         return obj.user_profile.user.username
#     get_user.short_description = 'User'  # Custom column header in the admin list view

#     # Add a custom admin action to manually approve the withdrawal request
#     def approve_withdrawal_request(self, request, queryset):
#         # Manually approve withdrawal request and update the status
#         for withdrawal in queryset:
#             if not withdrawal.approved:
#                 withdrawal.approved = True
#                 withdrawal.save()

#                 # Create the corresponding transaction for the approved withdrawal
#                 Transaction.objects.create(
#                     user=withdrawal.user_profile.user,
#                     amount=withdrawal.amount,
#                     transaction_type='withdrawal',
#                     status='approved',
#                     description="Approved Withdrawal"
#                 )

#                 # Deduct the withdrawal amount from the user's balance
#                 user_profile = withdrawal.user_profile
#                 user_profile.balance -= withdrawal.amount
#                 user_profile.save()

#     approve_withdrawal_request.short_description = "Manually approve selected withdrawal requests"  # Custom action description

#     actions = ['approve_withdrawal_request']  # Register the action in the admin

# # Register the customized admin classes
# admin.site.register(Transaction, TransactionAdmin)
# admin.site.register(Investment, InvestmentAdmin)
# admin.site.register(WithdrawalRequest, WithdrawalRequestAdmin)


from django.contrib import admin
from .models import Transaction, Investment, WithdrawalRequest

# Customize the Transaction model in the admin
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'transaction_type', 'status', 'created_at', 'description')
    list_filter = ('transaction_type', 'status')  # Add filters to the sidebar
    search_fields = ('user__username', 'transaction_type', 'description')  # Add search functionality
    ordering = ('-created_at',)  # Order by latest created_at by default

# Customize the Investment model in the admin
class InvestmentAdmin(admin.ModelAdmin):
    list_display = ('get_user', 'deposit_amount', 'roi_accumulated', 'deposit_time', 'last_updated', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('user_profile__user__username', 'deposit_amount')
    ordering = ('-deposit_time',)

    def get_user(self, obj):
        """
        Custom method to get the username from the related UserProfile
        """
        return obj.user_profile.user.username
    get_user.short_description = 'User'  # Custom column header in the admin list view

# Customize the WithdrawalRequest model in the admin
class WithdrawalRequestAdmin(admin.ModelAdmin):
    list_display = ('get_user', 'amount', 'created_at', 'approved')
    list_filter = ('approved',)  # Filter by approval status
    search_fields = ('user_profile__user__username', 'amount')
    ordering = ('-created_at',)  # Ensure new requests appear first by ordering by created_at

    # Custom method to get the username from the related UserProfile
    def get_user(self, obj):
        """
        Custom method to get the username from the related UserProfile
        """
        return obj.user_profile.user.username
    get_user.short_description = 'User'  # Custom column header in the admin list view

    # Add a custom admin action to manually approve the withdrawal request
    def approve_withdrawal_request(self, request, queryset):
        # Manually approve withdrawal request and update the status
        for withdrawal in queryset:
            if not withdrawal.approved:
                withdrawal.approved = True
                withdrawal.save()

                # Create the corresponding transaction for the approved withdrawal
                Transaction.objects.create(
                    user=withdrawal.user_profile.user,
                    amount=withdrawal.amount,
                    transaction_type='withdrawal',
                    status='approved',
                    description="Approved Withdrawal"
                )

                # Deduct the withdrawal amount from the user's balance
                user_profile = withdrawal.user_profile
                user_profile.balance -= withdrawal.amount
                user_profile.save()

    approve_withdrawal_request.short_description = "Manually approve selected withdrawal requests"  # Custom action description

    actions = ['approve_withdrawal_request']  # Register the action in the admin

    # To ensure all requests show up, you can adjust the admin's filtering:
    # Comment out `list_filter` temporarily to view all requests without approval-based filtering
    # list_filter = ('approved',)  # Keep this if you want to filter by approval status
    # Or, for testing, temporarily disable this filter:
    # list_filter = ()  

    # Optional: you may also want to include the "is_active" or another filter to help manage the visibility of requests in the admin
    # Example: list_filter = ('approved', 'is_active')

# Register the customized admin classes
admin.site.register(Transaction, TransactionAdmin)
admin.site.register(Investment, InvestmentAdmin)
admin.site.register(WithdrawalRequest, WithdrawalRequestAdmin)
